// src/lib/constants.ts
var DEFAULT_STORAGE = {
  lastSyncCount: 0,
  lastSyncDate: null,
  syncStatus: "idle",
  syncError: null,
  scrapeProgress: { found: 0, scrolls: 0 },
  uploadProgress: { sent: 0, total: 0 },
  supabaseUrl: null,
  supabaseAccessToken: null,
  userId: null,
  dashboardUrl: "http://127.0.0.1:3000"
};
var BATCH_SIZE = 15;
var DEFAULT_SUPABASE_URL = "http://127.0.0.1:54321";

// src/lib/storage.ts
async function getStorage() {
  const result = await chrome.storage.local.get(null);
  return { ...DEFAULT_STORAGE, ...result };
}
async function patchStorage(patch) {
  const current = await getStorage();
  const next = { ...current, ...patch };
  await chrome.storage.local.set(next);
  return next;
}
async function setSyncStatus(syncStatus, extra = {}) {
  await patchStorage({ syncStatus, ...extra });
}

// src/background.ts
function mapPostForApi(post) {
  return {
    ig_url: post.post_url,
    caption: post.caption,
    image_alt: post.image_alt,
    thumbnail_url: post.thumbnail_url,
    source_account: post.account_name,
    collection_name: post.collection_name,
    ig_saved_at: post.saved_at
  };
}
async function uploadPosts(posts) {
  const storage = await getStorage();
  const supabaseUrl = storage.supabaseUrl ?? DEFAULT_SUPABASE_URL;
  const { supabaseAccessToken, userId } = storage;
  if (!supabaseAccessToken || !userId) {
    throw new Error(
      "Connect your STASH account in the popup before uploading."
    );
  }
  await setSyncStatus("uploading", {
    syncError: null,
    uploadProgress: { sent: 0, total: posts.length }
  });
  for (let index = 0; index < posts.length; index += BATCH_SIZE) {
    const batch = posts.slice(index, index + BATCH_SIZE);
    const response = await fetch(`${supabaseUrl}/functions/v1/classify-posts`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${supabaseAccessToken}`
      },
      body: JSON.stringify({
        user_id: userId,
        posts: batch.map(mapPostForApi)
      })
    });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(body || `Upload failed with status ${response.status}`);
    }
    await patchStorage({
      uploadProgress: {
        sent: Math.min(index + batch.length, posts.length),
        total: posts.length
      }
    });
  }
  await setSyncStatus("classifying");
  await patchStorage({
    syncStatus: "complete",
    lastSyncCount: posts.length,
    lastSyncDate: (/* @__PURE__ */ new Date()).toISOString(),
    syncError: null,
    uploadProgress: { sent: posts.length, total: posts.length }
  });
}
async function handlePostsScraped(posts) {
  if (posts.length === 0) {
    await setSyncStatus("error", {
      syncError: "No saved posts found on this page."
    });
    return;
  }
  try {
    await uploadPosts(posts);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Upload failed.";
    await setSyncStatus("error", { syncError: errorMessage });
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  switch (message.type) {
    case "SYNC_STARTED":
      void setSyncStatus("scraping", {
        syncError: null,
        scrapeProgress: { found: 0, scrolls: 0 },
        uploadProgress: { sent: 0, total: 0 }
      });
      sendResponse({ ok: true });
      return false;
    case "SCRAPE_PROGRESS":
      void patchStorage({
        scrapeProgress: {
          found: message.found,
          scrolls: message.scrolls
        }
      });
      sendResponse({ ok: true });
      return false;
    case "POSTS_SCRAPED":
      void handlePostsScraped(message.posts);
      sendResponse({ ok: true });
      return false;
    case "GET_SYNC_STATE":
      void getStorage().then((state) => {
        sendResponse({ ok: true, state });
      });
      return true;
    case "SAVE_AUTH":
      void patchStorage({
        supabaseUrl: message.supabaseUrl,
        supabaseAccessToken: message.supabaseAccessToken,
        userId: message.userId,
        syncError: null
      }).then((state) => {
        sendResponse({ ok: true, state });
      });
      return true;
    case "RESET_SYNC":
      void patchStorage({
        syncStatus: "idle",
        syncError: null,
        scrapeProgress: { found: 0, scrolls: 0 },
        uploadProgress: { sent: 0, total: 0 }
      }).then((state) => {
        sendResponse({ ok: true, state });
      });
      return true;
    default:
      return false;
  }
});
console.info("[STASH] background service worker ready");
function handleSaveAuth(message) {
  return patchStorage({
    supabaseUrl: message.supabaseUrl,
    supabaseAccessToken: message.supabaseAccessToken,
    userId: message.userId,
    syncError: null
  });
}
chrome.runtime.onMessageExternal.addListener(
  (message, _sender, sendResponse) => {
    if (message.type === "SAVE_AUTH") {
      void handleSaveAuth(message).then((state) => {
        sendResponse({ ok: true, state });
      });
      return true;
    }
    if (message.type === "GET_SYNC_STATE") {
      void getStorage().then((state) => {
        sendResponse({ ok: true, state });
      });
      return true;
    }
    return false;
  }
);
//# sourceMappingURL=background.js.map
