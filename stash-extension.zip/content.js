// src/lib/constants.ts
var DEFAULT_STORAGE = {
  lastSyncCount: 0,
  lastSyncDate: null,
  syncStatus: "idle",
  syncError: null,
  scrapeProgress: { found: 0, scrolls: 0 },
  uploadProgress: { sent: 0, total: 0 },
  supabaseUrl: null,
  supabaseAccessToken: null,
  userId: null,
  dashboardUrl: "http://127.0.0.1:3000"
};
var SCROLL_DELAY_MS = 1200;
var SCROLL_JITTER_MS = 200;
var MAX_UNCHANGED_SCROLLS = 2;

// src/lib/storage.ts
async function getStorage() {
  const result = await chrome.storage.local.get(null);
  return { ...DEFAULT_STORAGE, ...result };
}
async function patchStorage(patch) {
  const current = await getStorage();
  const next = { ...current, ...patch };
  await chrome.storage.local.set(next);
  return next;
}
async function setSyncStatus(syncStatus, extra = {}) {
  await patchStorage({ syncStatus, ...extra });
}
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function normalizePostUrl(href) {
  try {
    const url = new URL(href, "https://www.instagram.com");
    if (!url.pathname.includes("/p/") && !url.pathname.includes("/reel/")) {
      return null;
    }
    return `${url.origin}${url.pathname}`.replace(/\/$/, "");
  } catch {
    return null;
  }
}
function dedupePosts(posts) {
  const seen = /* @__PURE__ */ new Set();
  const result = [];
  for (const post of posts) {
    if (seen.has(post.post_url)) {
      continue;
    }
    seen.add(post.post_url);
    result.push(post);
  }
  return result;
}

// src/content.ts
function isSavedPage() {
  return /instagram\.com\/[^/]+\/saved/.test(window.location.href);
}
function getCollectionName() {
  const collectionMatch = window.location.pathname.match(
    /\/saved\/([^/]+)\/?$/
  );
  if (collectionMatch?.[1]) {
    return decodeURIComponent(collectionMatch[1].replace(/-/g, " "));
  }
  const header = document.querySelector("header h1, main h1, h1");
  const text = header?.textContent?.trim();
  if (text && text.toLowerCase() !== "saved") {
    return text;
  }
  return null;
}
function countPostLinks() {
  return document.querySelectorAll(
    'a[href*="/p/"], a[href*="/reel/"]'
  ).length;
}
async function scrollUntilComplete(onProgress) {
  let unchangedScrolls = 0;
  let lastCount = countPostLinks();
  let scrolls = 0;
  onProgress(lastCount, scrolls);
  while (unchangedScrolls < MAX_UNCHANGED_SCROLLS) {
    window.scrollTo({
      top: document.documentElement.scrollHeight,
      behavior: "smooth"
    });
    const jitter = Math.floor(Math.random() * SCROLL_JITTER_MS);
    await sleep(SCROLL_DELAY_MS + jitter);
    scrolls += 1;
    const currentCount = countPostLinks();
    onProgress(currentCount, scrolls);
    if (currentCount === lastCount) {
      unchangedScrolls += 1;
    } else {
      unchangedScrolls = 0;
      lastCount = currentCount;
    }
  }
}
function extractAccountName(link) {
  const href = link.getAttribute("href");
  if (!href) {
    return null;
  }
  const match = href.match(/^\/([^/]+)\/(p|reel)\//);
  if (match?.[1] && match[1] !== "p" && match[1] !== "reel") {
    return match[1];
  }
  const label = link.getAttribute("aria-label");
  if (label) {
    const accountMatch = label.match(/^([^'"]+)/);
    if (accountMatch?.[1]) {
      return accountMatch[1].trim();
    }
  }
  return null;
}
function extractSavedAt(container) {
  if (!container) {
    return null;
  }
  const timeElement = container.querySelector("time");
  const datetime = timeElement?.getAttribute("datetime");
  return datetime ?? null;
}
function extractPosts() {
  const collectionName = getCollectionName();
  const posts = [];
  const links = document.querySelectorAll(
    'a[href*="/p/"], a[href*="/reel/"]'
  );
  for (const link of Array.from(links)) {
    const href = link.getAttribute("href");
    if (!href) {
      continue;
    }
    const postUrl = normalizePostUrl(href);
    if (!postUrl) {
      continue;
    }
    const container = link.closest("article") ?? link.closest('[role="presentation"]') ?? link.parentElement;
    const image = link.querySelector("img") ?? container?.querySelector("img") ?? null;
    posts.push({
      post_url: postUrl,
      caption: image?.alt?.trim() || null,
      image_alt: image?.alt?.trim() || null,
      thumbnail_url: image?.src || null,
      account_name: extractAccountName(link),
      collection_name: collectionName,
      saved_at: extractSavedAt(container)
    });
  }
  return dedupePosts(posts);
}
async function runScrape() {
  if (!isSavedPage()) {
    throw new Error("Open an Instagram Saved page before syncing.");
  }
  await chrome.runtime.sendMessage({ type: "SYNC_STARTED" });
  await scrollUntilComplete((found, scrolls) => {
    void chrome.runtime.sendMessage({
      type: "SCRAPE_PROGRESS",
      found,
      scrolls
    });
  });
  const posts = extractPosts();
  await chrome.runtime.sendMessage({
    type: "POSTS_SCRAPED",
    posts
  });
  return posts;
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== "START_SCRAPE") {
    return false;
  }
  runScrape().then((posts) => {
    sendResponse({ ok: true, count: posts.length });
  }).catch((error) => {
    const errorMessage = error instanceof Error ? error.message : "Scrape failed.";
    void setSyncStatus("error", { syncError: errorMessage });
    sendResponse({ ok: false, error: errorMessage });
  });
  return true;
});
console.info("[STASH] content script ready on saved page");
//# sourceMappingURL=content.js.map
